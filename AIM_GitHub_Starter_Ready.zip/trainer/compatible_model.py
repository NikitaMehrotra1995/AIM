"""Standalone, editable PyTorch implementation of the AIM v0.1 supported model.
Only the model/training code is open; the AIM analyzer is a separate executable.
"""
from dataclasses import asdict, dataclass
import math
import torch
import torch.nn as nn
import torch.nn.functional as F

@dataclass
class Config:
    n_layer: int = 1
    d_model: int = 4
    n_head: int = 1
    d_ff: int = 6
    dropout: float = 0.0
    max_seq_len: int = 33
    vocab_size: int = 14
    pos_rank: int = 2
    qkv_rank: int = 3
    attn_out_rank: int = 3
    ffn_rank: int = 3
    use_rmsnorm: bool = True
    norm_type: str = ''
    tie_qkv: str = 'shareA_tieKV'
    pe_type: str = 'learned'
    pe_init_period: float = 11.0
    token_emb_rank: int = 0
    use_index_emb: bool = False
    lm_head_rank: int = 0

    def validate(self):
        assert self.n_layer == self.n_head == 1
        assert self.use_rmsnorm and self.tie_qkv == 'shareA_tieKV'
        assert self.pe_type == 'learned' and self.token_emb_rank == self.lm_head_rank == 0
        assert self.d_model > 0 and self.vocab_size > 1 and self.max_seq_len >= 2
        for r in [self.pos_rank, self.qkv_rank, self.attn_out_rank, self.ffn_rank]:
            assert r > 0, 'rank factorization must be enabled'

class LowRankLinear(nn.Module):
    def __init__(self, din, dout, rank):
        super().__init__()
        self.A = nn.Parameter(torch.randn(din, rank) * math.sqrt(2 / (din + rank)))
        self.B = nn.Parameter(torch.randn(rank, dout) * math.sqrt(2 / (rank + dout)))
    def forward(self, x):
        return (x @ self.A) @ self.B

class LowRankEmbedding(nn.Module):
    def __init__(self, n, d, rank):
        super().__init__()
        self.A = nn.Parameter(torch.randn(n, rank) * 0.02)
        self.B = nn.Parameter(torch.randn(rank, d) * 0.02)
    def forward(self, indexes):
        return F.embedding(indexes, self.A) @ self.B

class RMSNorm(nn.Module):
    def __init__(self, d):
        super().__init__()
        self.weight = nn.Parameter(torch.ones(d))
    def forward(self, x):
        return x * torch.rsqrt(torch.mean(x*x, dim=-1, keepdim=True) + 1e-8) * self.weight

class Attention(nn.Module):
    def __init__(self, cfg):
        super().__init__()
        d, rank = cfg.d_model, cfg.qkv_rank
        self.qkv_A = nn.Parameter(torch.randn(d, rank) * math.sqrt(2 / (d + rank)))
        self.qkv_Bq = nn.Parameter(torch.randn(rank, d) * math.sqrt(2 / (rank + d)))
        self.qkv_Bkv = nn.Parameter(torch.randn(rank, d) * math.sqrt(2 / (rank + d)))
        self.proj = LowRankLinear(d, d, cfg.attn_out_rank)
    def forward(self, x):
        h = x @ self.qkv_A
        q, kv = h @ self.qkv_Bq, h @ self.qkv_Bkv
        s = q @ kv.transpose(-1, -2) / math.sqrt(q.shape[-1])
        t = s.shape[-1]
        mask = torch.ones(t,t,device=x.device,dtype=torch.bool).tril()
        att = torch.softmax(s.masked_fill(~mask, -torch.inf), dim=-1)
        return self.proj(att @ kv)

class MLP(nn.Module):
    def __init__(self, cfg):
        super().__init__()
        self.fc1 = LowRankLinear(cfg.d_model, cfg.d_ff, cfg.ffn_rank)
        self.fc2 = LowRankLinear(cfg.d_ff, cfg.d_model, cfg.ffn_rank)
    def forward(self, x):
        return self.fc2(F.gelu(self.fc1(x), approximate='none'))

class Block(nn.Module):
    def __init__(self,cfg):
        super().__init__()
        self.ln1 = RMSNorm(cfg.d_model)
        self.attn = Attention(cfg)
        self.ln2 = RMSNorm(cfg.d_model)
        self.mlp = MLP(cfg)
    def forward(self,x):
        x = x+self.attn(self.ln1(x))
        return x+self.mlp(self.ln2(x))

class CompatibleTransformer(nn.Module):
    def __init__(self, cfg):
        super().__init__()
        cfg.validate()
        self.cfg = cfg
        self.token_emb = nn.Embedding(cfg.vocab_size, cfg.d_model)
        self.pos_emb = LowRankEmbedding(cfg.max_seq_len, cfg.d_model, cfg.pos_rank)
        self.blocks = nn.ModuleList([Block(cfg)])
        self.ln_f = RMSNorm(cfg.d_model)
        self.lm_head = nn.Linear(cfg.d_model,cfg.vocab_size,bias=False)
        self.lm_head.weight = self.token_emb.weight  # tied output embedding
        nn.init.normal_(self.token_emb.weight, mean=0, std=0.02)
    def forward(self, idx):
        if idx.ndim != 2 or idx.shape[1] > self.cfg.max_seq_len:
            raise ValueError('Input must be [batch, <= max_seq_len]')
        pos = torch.arange(idx.shape[1],device=idx.device)
        x = self.token_emb(idx) + self.pos_emb(pos)[None,:,:]
        for block in self.blocks:
            x = block(x)
        return self.lm_head(self.ln_f(x))

    def checkpoint(self, **metadata):
        return {
            'model_config': asdict(self.cfg),
            'model_state': self.state_dict(),
            'params': sum(p.numel() for p in self.parameters()),
            **metadata,
        }
