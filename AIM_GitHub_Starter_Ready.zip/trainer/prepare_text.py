"""Convert one-text-example-per-line to token-ID JSONL via character tokenizer.
Vocabulary is created from data, with EOS at index 0; whitespace is significant.
The resulting tokenizer.json should be shared with anyone interpreting predictions.
"""
import argparse
import json
from pathlib import Path

p=argparse.ArgumentParser()
p.add_argument('--input',required=True)
p.add_argument('--out',default='data/tokenized.jsonl')
p.add_argument('--tokenizer',default='data/tokenizer.json')
p.add_argument('--max-vocab',type=int,default=14)
a=p.parse_args()
lines=[x for x in Path(a.input).read_text().splitlines() if x]
if not lines: raise ValueError('No nonempty lines')
chars=sorted(set(''.join(lines)))
if len(chars)+1>a.max_vocab:
    raise ValueError(f'Found {len(chars)} unique characters + EOS; max supported here is {a.max_vocab}. Use token IDs or increase --max-vocab (and train --vocab-size).')
vocab={c:i+1 for i,c in enumerate(chars)}
Path(a.out).parent.mkdir(parents=True,exist_ok=True)
with open(a.out,'w') as fp:
    for line in lines:
        print(json.dumps([vocab[c] for c in line]+[0]),file=fp)
Path(a.tokenizer).parent.mkdir(parents=True,exist_ok=True)
Path(a.tokenizer).write_text(json.dumps({'eos_id':0,'character_to_id':vocab,'vocab_size':a.max_vocab},indent=2))
print(f'Wrote {a.out}, tokenizer {a.tokenizer}; actual characters={len(chars)}, configured vocabulary={a.max_vocab}')
