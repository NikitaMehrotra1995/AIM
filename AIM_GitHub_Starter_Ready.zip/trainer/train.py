"""Train an AIM v0.1-compatible transformer on user token sequences.
Example: python trainer/train.py --data data/toy_sequences.jsonl --steps 50 --out trained.pt
Each JSONL line is a list of token IDs such as [0, 1, 2, 3].
"""
import argparse
import json
import random
import sys
from pathlib import Path

import torch
import torch.nn.functional as F

sys.path.insert(0, str(Path(__file__).parent))
from compatible_model import Config, CompatibleTransformer


def read_sequences(path, vocab_size):
    data = []
    for line_no,line in enumerate(Path(path).read_text().splitlines(),1):
        if not line.strip():
            continue
        seq = json.loads(line)
        if not isinstance(seq,list) or any(type(x) is not int or not 0 <= x < vocab_size for x in seq):
            raise ValueError(f'Invalid token sequence on line {line_no}: expected integer IDs 0..{vocab_size-1}')
        if len(seq) >= 2:
            data.append(seq)
    if not data:
        raise ValueError('No sequences with at least 2 tokens')
    return data


def batch_sequences(data, batch_size, max_seq_len, rng, device):
    """Random variable-length substrings, pad targets with -100 and ignore them in loss."""
    windows=[]
    for _ in range(batch_size):
        seq = rng.choice(data)
        start = rng.randrange(max(1,len(seq)-1))
        window=seq[start:start+max_seq_len+1]
        if len(window) < 2:
            window=seq[-2:]
        windows.append(window)
    n = min(max_seq_len, max(len(w)-1 for w in windows))
    x=torch.zeros(batch_size,n,dtype=torch.long)
    y=torch.full((batch_size,n),-100,dtype=torch.long)
    for i,w in enumerate(windows):
        length=min(n,len(w)-1)
        x[i,:length]=torch.tensor(w[:length])
        y[i,:length]=torch.tensor(w[1:length+1])
    return x.to(device),y.to(device)


def main():
    parser=argparse.ArgumentParser(description='Train a checkpoint compatible with AIM v0.1')
    parser.add_argument('--data',required=True,help='JSONL: one list of token IDs per line')
    parser.add_argument('--out',default='trained.pt')
    parser.add_argument('--steps',type=int,default=500)
    parser.add_argument('--batch-size',type=int,default=64)
    parser.add_argument('--lr',type=float,default=0.003)
    parser.add_argument('--seed',type=int,default=42)
    parser.add_argument('--device',default='cpu',choices=['cpu','cuda','mps'])
    parser.add_argument('--vocab-size',type=int,default=14)
    parser.add_argument('--max-seq-len',type=int,default=33)
    parser.add_argument('--log-every',type=int,default=50)
    args=parser.parse_args()
    if args.steps < 1 or args.batch_size < 1:
        parser.error('--steps and --batch-size must be positive')
    random.seed(args.seed);torch.manual_seed(args.seed)
    cfg=Config(vocab_size=args.vocab_size,max_seq_len=args.max_seq_len)
    data=read_sequences(args.data,cfg.vocab_size)
    model=CompatibleTransformer(cfg).to(args.device)
    opt=torch.optim.AdamW(model.parameters(),lr=args.lr)
    rng=random.Random(args.seed)
    for step in range(args.steps):
        model.train()
        x,y=batch_sequences(data,args.batch_size,cfg.max_seq_len,rng,args.device)
        logits=model(x)
        loss=F.cross_entropy(logits.reshape(-1,cfg.vocab_size),y.reshape(-1),ignore_index=-100)
        opt.zero_grad(set_to_none=True)
        loss.backward()
        torch.nn.utils.clip_grad_norm_(model.parameters(),1.0)
        opt.step()
        if step % args.log_every == 0 or step==args.steps-1:
            print(f'step={step+1}/{args.steps} loss={loss.item():.5f}')
    out=Path(args.out)
    out.parent.mkdir(parents=True,exist_ok=True)
    torch.save(model.checkpoint(step=args.steps,training_loss=float(loss.item())),out)
    print(f'Saved {out} | unique parameters={sum(p.numel() for p in model.parameters())}')
    print('Analyze with: ./bin/aim-linux-x86_64 analyze --weights '+str(out)+' --out ./results')

if __name__=='__main__':
    main()
